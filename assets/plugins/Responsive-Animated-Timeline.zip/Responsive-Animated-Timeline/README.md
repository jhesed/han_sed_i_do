# TimeLine

Simple elegant plugin time line slider.

![DEMO](https://github.com/AhmedBHameed/TimeLine/blob/master/img/DEMO.gif)

# Getting started

This plugin used with Jquery library so make sure to attache this plugin after importing jquery to your project.

# Licenses

This is MIT software licenses. Feel free to use it.
