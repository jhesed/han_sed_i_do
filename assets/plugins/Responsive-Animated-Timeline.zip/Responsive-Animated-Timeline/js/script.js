$('.timeLine').timeLine({
        mainColor: '#4DB7AA',
        opacity: '0.85',
        lineColor: '#fafafa'
    });
