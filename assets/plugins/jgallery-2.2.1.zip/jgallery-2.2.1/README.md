<p>Demo, usage example and configuration http://jgallery.jakubkowalczyk.pl.
</p>
