import { GalleryDecorator } from './index';
declare const withPreviewSizeChanger: GalleryDecorator;
export default withPreviewSizeChanger;
