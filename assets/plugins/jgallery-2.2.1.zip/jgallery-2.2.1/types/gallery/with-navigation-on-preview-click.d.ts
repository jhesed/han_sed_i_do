import { GalleryDecorator } from './index';
declare const withNavigationOnPreviewClick: GalleryDecorator;
export default withNavigationOnPreviewClick;
