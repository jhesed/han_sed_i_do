import { GalleryDecorator } from './index';
declare const withDraggablePreview: GalleryDecorator;
export default withDraggablePreview;
