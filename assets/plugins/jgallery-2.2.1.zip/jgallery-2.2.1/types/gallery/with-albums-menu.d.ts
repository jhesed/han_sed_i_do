import { GalleryDecorator } from './index';
declare const withAlbumsMenu: GalleryDecorator;
export default withAlbumsMenu;
