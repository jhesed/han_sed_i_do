import Params from './parameters';
declare const defaults: Params;
export default defaults;
