import { GalleryDecorator } from './index';
declare const withSlideShow: GalleryDecorator;
export default withSlideShow;
