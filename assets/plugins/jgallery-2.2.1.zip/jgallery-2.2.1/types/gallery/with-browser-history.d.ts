import { GalleryDecorator } from './index';
declare const withBrowserHistory: GalleryDecorator;
export default withBrowserHistory;
