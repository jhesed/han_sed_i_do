declare const _default: (src: string | HTMLElement) => Promise<void | void[]>;
export default _default;
