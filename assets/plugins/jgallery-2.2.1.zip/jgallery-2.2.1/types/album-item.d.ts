export default interface AlbumItem {
    url?: string;
    element?: HTMLElement;
    thumbUrl?: string;
    thumbElement?: HTMLElement;
    title?: string;
    hash?: string;
}
