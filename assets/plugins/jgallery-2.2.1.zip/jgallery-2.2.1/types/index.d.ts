import JGallery from './gallery/index';
export default JGallery;
