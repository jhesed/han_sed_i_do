export declare const touchSupport: number | true;
